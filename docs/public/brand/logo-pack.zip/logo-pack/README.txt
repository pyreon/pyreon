Pyreon logo pack

svg/  vector files. The wordmark is outlined to paths (Space Grotesk SemiBold), so no font is needed.
png/  512 and 1024 px wide exports. "on-dark"/"on-light" and marks without a background are transparent.

mark-color-on-dark      ember disc + paper n, for dark backgrounds
mark-color-on-light     ember disc + ink n, for light backgrounds
mark-mono-*             one colour; *-currentcolor follows CSS color
lockup-horizontal-*     mark + wordmark in a row
lockup-stacked-*        mark above the wordmark
lockup-*-split-*        "pyre" + ember "on": hero displays only, once per page

Rules (pyreon.dev/brand):
- Clear space: 11 units (half the disc radius, ~9% of the mark) on every side.
- Minimum size: colour 32 px, mono 16 px.
- Ember means "a signal changed". Don't use it as a background or a decorative border.
- Don't recolour the gradient, stretch, rotate or outline the mark.
